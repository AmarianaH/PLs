﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PriceCompareUI.Forms
{
    public partial class StoresForm : Form
    {
        public StoresForm()
        {
            InitializeComponent();
        }

        private void StoresForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the '_PriceCompareFramework_Handlers_DatabaseTDataSet1.Stores' table. You can move, or remove it, as needed.
            this.storesTableAdapter1.Fill(this._PriceCompareFramework_Handlers_DatabaseTDataSet1.Stores);
            // TODO: This line of code loads data into the '_PriceCompareFramework_Handlers_DatabaseTDataSet.Stores' table. You can move, or remove it, as needed.
            this.storesTableAdapter.Fill(this._PriceCompareFramework_Handlers_DatabaseTDataSet.Stores);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
